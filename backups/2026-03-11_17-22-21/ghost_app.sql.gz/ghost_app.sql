--
-- PostgreSQL database dump
--

\restrict 2fJeDxRFRudVdy4gTn7jP6AabQoGvR1gRInehb1VdDi1dkSXrj9kT73FQtQVLUy

-- Dumped from database version 16.13 (Debian 16.13-1.pgdg13+1)
-- Dumped by pg_dump version 16.13 (Debian 16.13-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: set_updated_at(); Type: FUNCTION; Schema: public; Owner: ghost
--

CREATE FUNCTION public.set_updated_at() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


ALTER FUNCTION public.set_updated_at() OWNER TO ghost;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: agents; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.agents (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    agent_key text NOT NULL,
    display_name text NOT NULL,
    agent_type text NOT NULL,
    provider text,
    model_name text,
    status text DEFAULT 'active'::text NOT NULL,
    capabilities jsonb DEFAULT '{}'::jsonb NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.agents OWNER TO ghost;

--
-- Name: approvals; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.approvals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid NOT NULL,
    requested_by_agent_id uuid,
    approval_type text NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    prompt_text text NOT NULL,
    response_text text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    responded_at timestamp with time zone,
    responded_by_user_id uuid
);


ALTER TABLE public.approvals OWNER TO ghost;

--
-- Name: artifacts; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.artifacts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid,
    conversation_id uuid,
    message_id uuid,
    artifact_type text NOT NULL,
    title text,
    storage_provider text DEFAULT 'local'::text NOT NULL,
    storage_path text NOT NULL,
    mime_type text,
    size_bytes bigint,
    checksum_sha256 text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.artifacts OWNER TO ghost;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.conversations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    owner_user_id uuid,
    title text,
    source text DEFAULT 'ghost'::text NOT NULL,
    status text DEFAULT 'open'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_message_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.conversations OWNER TO ghost;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    conversation_id uuid NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    content_format text DEFAULT 'text'::text NOT NULL,
    model_name text,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.messages OWNER TO ghost;

--
-- Name: service_health; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.service_health (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    service_name text NOT NULL,
    service_kind text NOT NULL,
    status text NOT NULL,
    message text,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    checked_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.service_health OWNER TO ghost;

--
-- Name: task_runs; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.task_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid NOT NULL,
    run_number integer DEFAULT 1 NOT NULL,
    execution_target text,
    status text DEFAULT 'queued'::text NOT NULL,
    n8n_workflow_name text,
    n8n_execution_id text,
    worker_name text,
    input_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    output_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    error_text text,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    duration_ms bigint
);


ALTER TABLE public.task_runs OWNER TO ghost;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.tasks (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    parent_task_id uuid,
    conversation_id uuid,
    requested_by_user_id uuid,
    assigned_agent_id uuid,
    title text NOT NULL,
    task_type text NOT NULL,
    source text DEFAULT 'ghost'::text NOT NULL,
    status text DEFAULT 'inbox'::text NOT NULL,
    priority integer DEFAULT 50 NOT NULL,
    current_phase text,
    input jsonb DEFAULT '{}'::jsonb NOT NULL,
    context jsonb DEFAULT '{}'::jsonb NOT NULL,
    result_summary text,
    error_summary text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    started_at timestamp with time zone,
    completed_at timestamp with time zone
);


ALTER TABLE public.tasks OWNER TO ghost;

--
-- Name: tool_events; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.tool_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    task_id uuid,
    task_run_id uuid,
    agent_id uuid,
    tool_name text NOT NULL,
    event_type text NOT NULL,
    status text DEFAULT 'ok'::text NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.tool_events OWNER TO ghost;

--
-- Name: users; Type: TABLE; Schema: public; Owner: ghost
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    email text,
    display_name text NOT NULL,
    role text DEFAULT 'owner'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.users OWNER TO ghost;

--
-- Data for Name: agents; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.agents (id, agent_key, display_name, agent_type, provider, model_name, status, capabilities, config, metadata, created_at, updated_at) FROM stdin;
683655f9-1177-4f61-b541-4341c270bf09	ghost-main	Ghost	orchestrator	hybrid	qwen3:14b	active	{"chat": true, "routing": true, "planning": true}	{}	{}	2026-03-11 17:21:48.954391+01	2026-03-11 17:21:48.954391+01
\.


--
-- Data for Name: approvals; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.approvals (id, task_id, requested_by_agent_id, approval_type, status, prompt_text, response_text, metadata, requested_at, responded_at, responded_by_user_id) FROM stdin;
\.


--
-- Data for Name: artifacts; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.artifacts (id, task_id, conversation_id, message_id, artifact_type, title, storage_provider, storage_path, mime_type, size_bytes, checksum_sha256, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.conversations (id, owner_user_id, title, source, status, metadata, created_at, updated_at, last_message_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.messages (id, conversation_id, role, content, content_format, model_name, metadata, created_at) FROM stdin;
\.


--
-- Data for Name: service_health; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.service_health (id, service_name, service_kind, status, message, details, checked_at) FROM stdin;
\.


--
-- Data for Name: task_runs; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.task_runs (id, task_id, run_number, execution_target, status, n8n_workflow_name, n8n_execution_id, worker_name, input_payload, output_payload, error_text, started_at, finished_at, duration_ms) FROM stdin;
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.tasks (id, parent_task_id, conversation_id, requested_by_user_id, assigned_agent_id, title, task_type, source, status, priority, current_phase, input, context, result_summary, error_summary, created_at, updated_at, started_at, completed_at) FROM stdin;
\.


--
-- Data for Name: tool_events; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.tool_events (id, task_id, task_run_id, agent_id, tool_name, event_type, status, payload, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: ghost
--

COPY public.users (id, email, display_name, role, status, metadata, created_at, updated_at) FROM stdin;
\.


--
-- Name: agents agents_agent_key_key; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_agent_key_key UNIQUE (agent_key);


--
-- Name: agents agents_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.agents
    ADD CONSTRAINT agents_pkey PRIMARY KEY (id);


--
-- Name: approvals approvals_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_pkey PRIMARY KEY (id);


--
-- Name: artifacts artifacts_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: service_health service_health_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.service_health
    ADD CONSTRAINT service_health_pkey PRIMARY KEY (id);


--
-- Name: task_runs task_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: tool_events tool_events_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tool_events
    ADD CONSTRAINT tool_events_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: idx_approvals_status_requested; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_approvals_status_requested ON public.approvals USING btree (status, requested_at);


--
-- Name: idx_artifacts_conversation; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_artifacts_conversation ON public.artifacts USING btree (conversation_id);


--
-- Name: idx_artifacts_task; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_artifacts_task ON public.artifacts USING btree (task_id);


--
-- Name: idx_messages_conversation_created; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_messages_conversation_created ON public.messages USING btree (conversation_id, created_at);


--
-- Name: idx_service_health_name_checked; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_service_health_name_checked ON public.service_health USING btree (service_name, checked_at);


--
-- Name: idx_task_runs_n8n_execution; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_task_runs_n8n_execution ON public.task_runs USING btree (n8n_execution_id);


--
-- Name: idx_task_runs_task_started; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_task_runs_task_started ON public.task_runs USING btree (task_id, started_at);


--
-- Name: idx_tasks_assigned_agent; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_tasks_assigned_agent ON public.tasks USING btree (assigned_agent_id);


--
-- Name: idx_tasks_status_priority_created; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_tasks_status_priority_created ON public.tasks USING btree (status, priority, created_at);


--
-- Name: idx_tool_events_run_created; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_tool_events_run_created ON public.tool_events USING btree (task_run_id, created_at);


--
-- Name: idx_tool_events_task_created; Type: INDEX; Schema: public; Owner: ghost
--

CREATE INDEX idx_tool_events_task_created ON public.tool_events USING btree (task_id, created_at);


--
-- Name: agents trg_agents_updated_at; Type: TRIGGER; Schema: public; Owner: ghost
--

CREATE TRIGGER trg_agents_updated_at BEFORE UPDATE ON public.agents FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: conversations trg_conversations_updated_at; Type: TRIGGER; Schema: public; Owner: ghost
--

CREATE TRIGGER trg_conversations_updated_at BEFORE UPDATE ON public.conversations FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: tasks trg_tasks_updated_at; Type: TRIGGER; Schema: public; Owner: ghost
--

CREATE TRIGGER trg_tasks_updated_at BEFORE UPDATE ON public.tasks FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: users trg_users_updated_at; Type: TRIGGER; Schema: public; Owner: ghost
--

CREATE TRIGGER trg_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();


--
-- Name: approvals approvals_requested_by_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_requested_by_agent_id_fkey FOREIGN KEY (requested_by_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: approvals approvals_responded_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_responded_by_user_id_fkey FOREIGN KEY (responded_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: approvals approvals_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.approvals
    ADD CONSTRAINT approvals_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: artifacts artifacts_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: artifacts artifacts_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_message_id_fkey FOREIGN KEY (message_id) REFERENCES public.messages(id) ON DELETE SET NULL;


--
-- Name: artifacts artifacts_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.artifacts
    ADD CONSTRAINT artifacts_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: conversations conversations_owner_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_owner_user_id_fkey FOREIGN KEY (owner_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE CASCADE;


--
-- Name: task_runs task_runs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.task_runs
    ADD CONSTRAINT task_runs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_assigned_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_assigned_agent_id_fkey FOREIGN KEY (assigned_agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_parent_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_parent_task_id_fkey FOREIGN KEY (parent_task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tasks tasks_requested_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_requested_by_user_id_fkey FOREIGN KEY (requested_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tool_events tool_events_agent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tool_events
    ADD CONSTRAINT tool_events_agent_id_fkey FOREIGN KEY (agent_id) REFERENCES public.agents(id) ON DELETE SET NULL;


--
-- Name: tool_events tool_events_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tool_events
    ADD CONSTRAINT tool_events_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: tool_events tool_events_task_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: ghost
--

ALTER TABLE ONLY public.tool_events
    ADD CONSTRAINT tool_events_task_run_id_fkey FOREIGN KEY (task_run_id) REFERENCES public.task_runs(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict 2fJeDxRFRudVdy4gTn7jP6AabQoGvR1gRInehb1VdDi1dkSXrj9kT73FQtQVLUy

